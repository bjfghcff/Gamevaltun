const $=s=>document.querySelector(s);
let products=[],game="ALL",kind="ALL",searchQuery="",cart=JSON.parse(localStorage.getItem("gv_cart")||"[]"),me=null;
const money=n=>(n/100).toLocaleString("ru-RU",{style:"currency",currency:"RUB",maximumFractionDigits:0});
function toast(s){const t=$("#toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function saveCart(){localStorage.setItem("gv_cart",JSON.stringify(cart));$("#cartCount").textContent=cart.reduce((n,x)=>n+x.quantity,0)}
function show(html){$("#modalContent").innerHTML=html;$("#modal").classList.remove("hidden")}
function hide(){$("#modal").classList.add("hidden")}
async function api(url,opts={}){const r=await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(opts.headers||{})},...opts});let d={};try{d=await r.json()}catch{}if(!r.ok)throw Error(d.error||"Ошибка запроса");return d}
async function loadProducts(){try{products=await api("/api/products");render()}catch(e){$("#products").textContent=e.message}}
function render(){const q=searchQuery.trim().toLocaleLowerCase("ru-RU");const list=products.filter(p=>(game==="ALL"||p.game===game)&&(kind==="ALL"||p.kind===kind)&&(!q||[p.title,p.description,p.game,p.kind].some(v=>String(v??"").toLocaleLowerCase("ru-RU").includes(q))));const label=$("#resultsLabel");if(label)label.textContent=`НАЙДЕНО: ${String(list.length).padStart(2,"0")}`;$("#products").innerHTML=list.map((p,i)=>`<article class="product" style="animation-delay:${Math.min(i*65,390)}ms"><img src="${esc(p.image)}" alt="${esc(p.title)}" loading="lazy"><div class="product-body"><div class="product-meta"><span>${esc(p.game)}</span><span>${p.kind==="account"?"АККАУНТ":"УСЛУГА"}</span></div><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p><div class="product-bottom"><strong class="price">${money(p.price)}</strong><button class="add" data-add="${esc(p.id)}">В КОРЗИНУ +</button></div></div></article>`).join("")||'<div class="loading">ПО ЭТОМУ ЗАПРОСУ НИЧЕГО НЕ НАЙДЕНО</div>'}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("#products").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id===b.dataset.add);const item=cart.find(x=>x.id===p.id);if(item)item.quantity=Math.min(10,item.quantity+1);else cart.push({id:p.id,quantity:1});saveCart();toast("Добавлено в корзину")});
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");game=b.dataset.game;render()});
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");kind=b.dataset.kind;render()});
const searchInput=$("#productSearch");if(searchInput)searchInput.addEventListener("input",e=>{searchQuery=e.target.value;render()});
$("#cartBtn").onclick=()=>{const rows=cart.map(x=>{const p=products.find(p=>p.id===x.id);return p?`<div class="cart-row"><span>${esc(p.title)} × ${x.quantity}</span><b>${money(p.price*x.quantity)}</b><button data-remove="${p.id}">Убрать</button></div>`:""}).join("");const total=cart.reduce((s,x)=>{const p=products.find(p=>p.id===x.id);return s+(p?p.price*x.quantity:0)},0);show(`<h2>КОРЗИНА</h2>${rows||'<p class="muted">Корзина пока пуста.</p>'}<div class="cart-row"><b>ИТОГО</b><b>${money(total)}</b></div><button class="wide" id="checkout" ${!cart.length?"disabled":""}>ОПЛАТИТЬ ЧЕРЕЗ СБП</button>`);$("#modalContent").addEventListener("click",e=>{if(e.target.dataset.remove){cart=cart.filter(x=>x.id!==e.target.dataset.remove);saveCart();$("#cartBtn").click()}if(e.target.id==="checkout")checkout()})};
async function checkout(){try{if(!me){toast("Сначала войдите в аккаунт");account();return}const d=await api("/api/checkout",{method:"POST",body:JSON.stringify({items:cart})});if(!d.paymentUrl)throw Error("Ссылка оплаты не получена");location.href=d.paymentUrl}catch(e){toast(e.message)}}
function account(){show(`<h2>ЛИЧНЫЙ КАБИНЕТ</h2><div class="field"><label>НИКНЕЙМ</label><input id="nick" autocomplete="username" placeholder="Ваш никнейм"></div><div class="field"><label>ПАРОЛЬ</label><input id="pass" type="password" autocomplete="current-password" placeholder="Не менее 10 символов"></div><button class="wide" id="login">ВОЙТИ</button><button class="line-btn" id="register">Создать аккаунт</button><p class="muted">Пароль хранится в виде криптографического хеша. Не используйте пароль от игровых аккаунтов.</p>`);$("#login").onclick=()=>auth("login");$("#register").onclick=()=>auth("register")}
async function auth(mode){try{const d=await api("/api/"+(mode==="login"?"login":"register"),{method:"POST",body:JSON.stringify({nickname:$("#nick").value,password:$("#pass").value})});me=d.user;$("#accountBtn").textContent=me.nickname;if(me.role==="admin")showAdminButton();toast("Вы вошли как "+me.nickname);hide()}catch(e){toast(e.message)}}
const GAMES=["PUBG","OXIDE","MINECRAFT","CS2","GTA","VALORANT","FORTNITE"];
const gameOptions=(sel="")=>GAMES.map(g=>`<option value="${g}" ${g===sel?"selected":""}>${g}</option>`).join("");
function showAdminButton(){
  if($("#adminBtn"))return;
  const b=document.createElement("button");b.id="adminBtn";b.className="ghost";b.textContent="Админ";b.onclick=()=>adminPanel("products");
  $(".actions").insertBefore(b,$("#cartBtn"));
}
function adminTabs(active){
  return `<div class="admin-tabs">
    <button class="admin-tab ${active==="products"?"active":""}" data-atab="products">ТОВАРЫ</button>
    <button class="admin-tab ${active==="orders"?"active":""}" data-atab="orders">ЗАКАЗЫ</button>
    <button class="admin-tab ${active==="users"?"active":""}" data-atab="users">ПОЛЬЗОВАТЕЛИ</button>
  </div>`;
}
function bindAdminTabs(){
  document.querySelectorAll("[data-atab]").forEach(b=>b.onclick=()=>adminPanel(b.dataset.atab));
}
async function adminPanel(tab="products"){
  try{
    if(!me)me=await api("/api/me");
    if(me.role!=="admin")throw Error("Нет прав администратора");
    if(tab==="products")return adminProducts();
    if(tab==="orders")return adminOrders();
    if(tab==="users")return adminUsers();
  }catch(e){toast(e.message)}
}
async function adminProducts(editId=null){
  const list=await api("/api/admin/products");
  const edit=editId?list.find(x=>x.id===editId):null;
  show(`<h2>ADMIN / ТОВАРЫ</h2>${adminTabs("products")}
    <h3 style="margin:0 0 8px;font:600 13px var(--display)">${edit?"Редактировать товар":"Новый товар"}</h3>
    <div class="admin-form-grid">
      <div class="field"><label>ИГРА</label><select id="agame">${gameOptions(edit?.game)}</select></div>
      <div class="field"><label>ТИП</label><select id="akind"><option value="account" ${edit?.kind==="account"?"selected":""}>Аккаунт</option><option value="service" ${edit?.kind==="service"?"selected":""}>Услуга</option></select></div>
    </div>
    <div class="field"><label>НАЗВАНИЕ</label><input id="atitle" maxlength="100" value="${esc(edit?.title||"")}"></div>
    <div class="field"><label>ОПИСАНИЕ</label><textarea id="adesc" rows="3">${esc(edit?.description||"")}</textarea></div>
    <div class="admin-form-grid">
      <div class="field"><label>ЦЕНА В РУБЛЯХ</label><input id="aprice" type="number" min="0" step="1" value="${edit?edit.price/100:""}"></div>
      <div class="field"><label>ОСТАТОК / ЛИМИТ</label><input id="astock" type="number" min="0" value="${edit?edit.stock:1}"></div>
    </div>
    <div class="field"><label>ИЗОБРАЖЕНИЕ URL</label><input id="aimage" value="${esc(edit?.image||"")}"></div>
    ${edit?`<div class="field"><label>СТАТУС</label><select id="aactive"><option value="1" ${edit.active?"selected":""}>Активен</option><option value="0" ${!edit.active?"selected":""}>Скрыт</option></select></div>`:""}
    <button class="wide" id="saveProduct">${edit?"СОХРАНИТЬ ИЗМЕНЕНИЯ":"ДОБАВИТЬ ТОВАР"}</button>
    ${edit?`<button class="line-btn" id="cancelEdit">← Отмена редактирования</button>`:""}
    <h3 style="margin:28px 0 8px;font:600 13px var(--display)">Каталог (${list.length})</h3>
    ${list.map(x=>`<div class="admin-row">
      <div class="admin-row-top">
        <span><b>${esc(x.game)}</b> · ${esc(x.title)}<br>
        <small class="muted">${money(x.price)} · Остаток: ${x.stock} · ${x.kind==="account"?"Аккаунт":"Услуга"}</small>
        <span class="admin-badge ${x.active?"badge-active":"badge-hidden"}">${x.active?"АКТИВЕН":"СКРЫТ"}</span></span>
      </div>
      <div class="admin-actions">
        <button data-edit="${x.id}">Изменить</button>
        <button data-toggle="${x.id}" data-active="${x.active}">${x.active?"Скрыть":"Включить"}</button>
        <button class="danger" data-del="${x.id}">Удалить</button>
      </div>
    </div>`).join("")||'<p class="muted">Товаров пока нет.</p>'}`);
  bindAdminTabs();
  $("#saveProduct").onclick=async()=>{
    try{
      const body={
        game:$("#agame").value,kind:$("#akind").value,title:$("#atitle").value,
        description:$("#adesc").value,price:Math.round(Number($("#aprice").value)*100),
        image:$("#aimage").value,stock:Number($("#astock").value)
      };
      if(edit){
        body.active=Number($("#aactive").value);
        await api("/api/admin/products/"+edit.id,{method:"PATCH",body:JSON.stringify(body)});
        toast("Товар обновлён");
      }else{
        await api("/api/admin/products",{method:"POST",body:JSON.stringify(body)});
        toast("Товар добавлен");
      }
      await loadProducts();adminProducts();
    }catch(e){toast(e.message)}
  };
  if($("#cancelEdit"))$("#cancelEdit").onclick=()=>adminProducts();
  $("#modalContent").onclick=async e=>{
    const editBtn=e.target.closest("[data-edit]");
    if(editBtn)return adminProducts(editBtn.dataset.edit);
    const tog=e.target.closest("[data-toggle]");
    if(tog){
      try{await api("/api/admin/products/"+tog.dataset.toggle,{method:"PATCH",body:JSON.stringify({active:Number(tog.dataset.active)?0:1})});await loadProducts();adminProducts()}catch(err){toast(err.message)}
    }
    const del=e.target.closest("[data-del]");
    if(del){
      if(!confirm("Удалить товар? Если он был в заказах — будет только скрыт."))return;
      try{await api("/api/admin/products/"+del.dataset.del,{method:"DELETE"});await loadProducts();toast("Готово");adminProducts()}catch(err){toast(err.message)}
    }
  };
}
async function adminOrders(){
  const orders=await api("/api/admin/orders");
  const statusBadge=s=>({pending:"badge-pending",paid:"badge-paid",canceled:"badge-canceled",fulfilled:"badge-fulfilled"}[s]||"badge-hidden");
  const statusLabel=s=>({pending:"Ожидает",paid:"Оплачен",canceled:"Отменён",fulfilled:"Выдан"}[s]||s);
  show(`<h2>ADMIN / ЗАКАЗЫ</h2>${adminTabs("orders")}
    ${orders.map(o=>`<div class="admin-row">
      <div class="admin-row-top">
        <span><b>${esc(o.nickname)}</b> · ${o.id.slice(0,8)}…<br>
        <small class="muted">${esc((o.items||[]).map(i=>i.title+" × "+i.quantity).join(", ")||"—")}</small><br>
        <span class="admin-badge ${statusBadge(o.status)}">${statusLabel(o.status)}</span>
        <small class="muted"> · ${new Date(o.created_at+"Z").toLocaleString("ru-RU")}</small></span>
        <b>${money(o.total)}</b>
      </div>
      <div class="admin-actions">
        ${o.status!=="paid"?`<button data-ostatus="${o.id}" data-s="paid">Оплачен</button>`:""}
        ${o.status!=="fulfilled"?`<button data-ostatus="${o.id}" data-s="fulfilled">Выдан</button>`:""}
        ${o.status!=="canceled"?`<button class="danger" data-ostatus="${o.id}" data-s="canceled">Отменить</button>`:""}
        ${o.status!=="pending"?`<button data-ostatus="${o.id}" data-s="pending">В ожидание</button>`:""}
      </div>
    </div>`).join("")||'<p class="muted">Заказов пока нет.</p>'}`);
  bindAdminTabs();
  $("#modalContent").onclick=async e=>{
    const b=e.target.closest("[data-ostatus]");
    if(!b)return;
    try{await api("/api/admin/orders/"+b.dataset.ostatus,{method:"PATCH",body:JSON.stringify({status:b.dataset.s})});toast("Статус обновлён");adminOrders()}catch(err){toast(err.message)}
  };
}
async function adminUsers(){
  const users=await api("/api/admin/users");
  show(`<h2>ADMIN / ПОЛЬЗОВАТЕЛИ</h2>${adminTabs("users")}
    ${users.map(u=>`<div class="admin-row">
      <div class="admin-row-top">
        <span><b>${esc(u.nickname)}</b>
        <span class="admin-badge ${u.role==="admin"?"badge-paid":"badge-hidden"}">${u.role==="admin"?"ADMIN":"USER"}</span><br>
        <small class="muted">${new Date(u.created_at+"Z").toLocaleString("ru-RU")}</small></span>
      </div>
      <div class="admin-actions">
        ${u.role==="user"?`<button data-urole="${u.id}" data-r="admin">Сделать админом</button>`:`<button class="danger" data-urole="${u.id}" data-r="user">Снять админа</button>`}
      </div>
    </div>`).join("")||'<p class="muted">Пользователей пока нет.</p>'}`);
  bindAdminTabs();
  $("#modalContent").onclick=async e=>{
    const b=e.target.closest("[data-urole]");
    if(!b)return;
    try{await api("/api/admin/users/"+b.dataset.urole,{method:"PATCH",body:JSON.stringify({role:b.dataset.r})});toast("Роль обновлена");adminUsers()}catch(err){toast(err.message)}
  };
}
$("#accountBtn").onclick=account;
$("#ordersBtn").onclick=async()=>{try{if(!me)me=await api("/api/me");const rows=await api("/api/orders");show(`<h2>ИСТОРИЯ ПОКУПОК</h2>${rows.map(o=>`<div class="order-row"><span>Заказ ${o.id.slice(0,8)}<br><small class="muted">${o.items.map(i=>esc(i.title)+" × "+i.quantity).join(", ")}</small></span><b>${money(o.total)}<br><small class="muted">${esc(o.status)}</small></b></div>`).join("")||'<p class="muted">Заказов пока нет.</p>'}`)}catch(e){toast(e.message);account()}};
$("#closeModal").onclick=hide;$("#modal").onclick=e=>{if(e.target.id==="modal")hide()};
(async()=>{saveCart();await loadProducts();try{me=await api("/api/me");$("#accountBtn").textContent=me.nickname;if(me.role==="admin")showAdminButton()}catch{}})();
