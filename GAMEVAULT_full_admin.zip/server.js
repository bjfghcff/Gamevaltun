require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const { v4: uuid } = require("uuid");
const crypto = require("crypto");
const path = require("path");

const app = express();
const db = new Database("gamevault.sqlite");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

const ALLOWED_GAMES = ["PUBG","OXIDE","MINECRAFT","CS2","GTA","VALORANT","FORTNITE"];
const ALLOWED_KINDS = ["account","service"];
const ALLOWED_ORDER_STATUSES = ["pending","paid","canceled","fulfilled"];

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, nickname TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, game TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL,
 description TEXT NOT NULL, price INTEGER NOT NULL CHECK(price >= 0),
 image TEXT NOT NULL DEFAULT '', stock INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 total INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 payment_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id),
 product_id TEXT NOT NULL REFERENCES products(id), title TEXT NOT NULL,
 quantity INTEGER NOT NULL, unit_price INTEGER NOT NULL
);
`);

const seed = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
if (!seed) {
  const add = db.prepare("INSERT INTO products(id,game,kind,title,description,price,image,stock) VALUES(?,?,?,?,?,?,?,?)");
  [
    ["PUBG","account","PUBG — стартовый профиль","Пример карточки. Характеристики и наличие уточняются у продавца.",149900,"https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900",1],
    ["OXIDE","account","OXIDE — игровой профиль","Демонстрационная позиция магазина.",79900,"https://images.unsplash.com/photo-1511512578047-dfb367046420?w=900",1],
    ["MINECRAFT","account","Minecraft — профиль","Демонстрационная позиция магазина.",99900,"https://images.unsplash.com/photo-1607513746994-51f730a44832?w=900",1],
    ["CS2","account","CS2 — аккаунт с рангом","Демонстрационная позиция. Ранг и скины уточняются у продавца.",189900,"https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900&sat=-100",1],
    ["GTA","account","GTA Online — прокачанный профиль","Демонстрационная позиция. Уровень, деньги и имущество уточняются.",249900,"https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=900",1],
    ["VALORANT","account","Valorant — аккаунт","Демонстрационная позиция. Ранг и агенты уточняются у продавца.",129900,"https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=900",1],
    ["FORTNITE","account","Fortnite — аккаунт с скинами","Демонстрационная позиция. Скины и боевой пропуск уточняются.",109900,"https://images.unsplash.com/photo-1589241062272-c0a000072dfa?w=900",1],
    ["PUBG","service","Прокачка PUBG","Согласование объёма и сроков после оформления заявки.",49900,"https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900",99],
    ["OXIDE","service","Прокачка OXIDE","Согласование объёма и сроков после оформления заявки.",39900,"https://images.unsplash.com/photo-1511512578047-dfb367046420?w=900",99],
    ["MINECRAFT","service","Услуги Minecraft","Согласование работ и сроков после оформления заявки.",29900,"https://images.unsplash.com/photo-1607513746994-51f730a44832?w=900",99],
    ["CS2","service","Буст ранга CS2","Согласование целевого ранга и сроков после заявки.",59900,"https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900&sat=-100",99],
    ["GTA","service","Прокачка GTA Online","Уровень, деньги, бизнес — обсуждается после оформления.",69900,"https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=900",99],
    ["VALORANT","service","Буст ранга Valorant","Согласование ранга и режима после оформления заявки.",54900,"https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=900",99],
    ["FORTNITE","service","Прокачка Fortnite","Боевой пропуск и уровни — условия после заявки.",44900,"https://images.unsplash.com/photo-1589241062272-c0a000072dfa?w=900",99]
  ].forEach(x => add.run(uuid(), ...x));
}

const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) {
  console.error("JWT_SECRET must be set to at least 32 characters. Copy .env.example to .env and configure it.");
  process.exit(1);
}

function tokenFor(user) {
  return jwt.sign({ sub: user.id, role: user.role, nickname: user.nickname }, secret, { expiresIn: "7d" });
}
function auth(req,res,next) {
  try {
    const t = req.cookies.gv_session || (req.headers.authorization || "").replace(/^Bearer /i,"");
    if (!t) return res.status(401).json({error:"Требуется вход"});
    req.user = jwt.verify(t, secret);
    next();
  } catch { return res.status(401).json({error:"Сессия истекла"}); }
}
function admin(req,res,next) {
  if (req.user?.role !== "admin") return res.status(403).json({error:"Доступ только администратору"});
  next();
}
const loginLimit = rateLimit({windowMs:15*60*1000, max:10, standardHeaders:true, legacyHeaders:false});
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"200kb"}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname,"public")));

app.get("/api/products",(req,res)=>{
  const {game,kind} = req.query;
  let sql = "SELECT id,game,kind,title,description,price,image,stock FROM products WHERE active=1";
  const args=[];
  if (game && ALLOWED_GAMES.includes(game)) {sql+=" AND game=?";args.push(game);}
  if (kind && ["account","service"].includes(kind)) {sql+=" AND kind=?";args.push(kind);}
  res.json(db.prepare(sql+" ORDER BY created_at DESC").all(...args));
});
app.post("/api/register",loginLimit,async(req,res)=>{
  const nickname=String(req.body.nickname||"").trim();
  const password=String(req.body.password||"");
  if(!/^[a-zA-Z0-9_]{3,20}$/.test(nickname)) return res.status(400).json({error:"Ник: 3–20 символов, латиница, цифры и _"});
  if(password.length<10 || password.length>128) return res.status(400).json({error:"Пароль должен содержать от 10 до 128 символов"});
  const hash=await bcrypt.hash(password,12), id=uuid();
  try {
    db.prepare("INSERT INTO users(id,nickname,password_hash) VALUES(?,?,?)").run(id,nickname,hash);
    const user={id,nickname,role:"user"};
    res.cookie("gv_session",tokenFor(user),{httpOnly:true,sameSite:"lax",secure:process.env.COOKIE_SECURE==="true",maxAge:7*864e5});
    res.json({user:{nickname,role:"user"}});
  } catch {res.status(409).json({error:"Этот никнейм уже занят"});}
});
app.post("/api/login",loginLimit,async(req,res)=>{
  const nickname=String(req.body.nickname||"").trim(), password=String(req.body.password||"");
  const user=db.prepare("SELECT * FROM users WHERE nickname=?").get(nickname);
  if(!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"Неверный никнейм или пароль"});
  res.cookie("gv_session",tokenFor(user),{httpOnly:true,sameSite:"lax",secure:process.env.COOKIE_SECURE==="true",maxAge:7*864e5});
  res.json({user:{nickname:user.nickname,role:user.role}});
});
app.post("/api/logout",(req,res)=>{res.clearCookie("gv_session");res.json({ok:true});});
app.get("/api/me",auth,(req,res)=>res.json({nickname:req.user.nickname,role:req.user.role}));
app.get("/api/orders",auth,(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC").all(req.user.sub);
  const items=db.prepare("SELECT * FROM order_items WHERE order_id=?");
  res.json(orders.map(o=>({...o,items:items.all(o.id)})));
});
app.post("/api/checkout",auth,async(req,res)=>{
  const ids=req.body.items;
  if(!Array.isArray(ids)||!ids.length||ids.length>30) return res.status(400).json({error:"Корзина пуста или слишком велика"});
  const counts=new Map();
  for(const x of ids){const id=String(x.id||"");const q=Math.max(1,Math.min(10,Number(x.quantity)||1));counts.set(id,Math.min(10,(counts.get(id)||0)+q));}
  const selected=[];
  for(const [id,q] of counts){
    const p=db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(id);
    if(!p || p.stock<q) return res.status(400).json({error:"Товар отсутствует или недостаточно остатка"});
    selected.push({...p,quantity:q});
  }
  const total=selected.reduce((s,p)=>s+p.price*p.quantity,0);
  if(!process.env.YOOKASSA_SHOP_ID||!process.env.YOOKASSA_SECRET_KEY) return res.status(503).json({error:"Оплата ещё не настроена. Добавьте ключи YooKassa в .env"});
  const orderId=uuid();
  const createOrder=db.transaction(()=>{
    db.prepare("INSERT INTO orders(id,user_id,total,status) VALUES(?,?,?,'pending')").run(orderId,req.user.sub,total);
    const ins=db.prepare("INSERT INTO order_items(id,order_id,product_id,title,quantity,unit_price) VALUES(?,?,?,?,?,?)");
    selected.forEach(p=>ins.run(uuid(),orderId,p.id,p.title,p.quantity,p.price));
  });
  createOrder();
  try{
    const idem=crypto.randomUUID();
    const credentials=Buffer.from(process.env.YOOKASSA_SHOP_ID+":"+process.env.YOOKASSA_SECRET_KEY).toString("base64");
    const r=await fetch("https://api.yookassa.ru/v3/payments",{
      method:"POST",
      headers:{"Authorization":"Basic "+credentials,"Idempotence-Key":idem,"Content-Type":"application/json"},
      body:JSON.stringify({
        amount:{value:(total/100).toFixed(2),currency:"RUB"},
        capture:true,
        confirmation:{type:"redirect",return_url:process.env.YOOKASSA_RETURN_URL||process.env.BASE_URL+"/payment/return"},
        payment_method_data:{type:"sbp"},
        description:"GAMEVAULT заказ "+orderId,
        metadata:{order_id:orderId,user_id:req.user.sub}
      })
    });
    const data=await r.json();
    if(!r.ok) throw new Error(data.description||"YooKassa API error");
    db.prepare("UPDATE orders SET payment_id=? WHERE id=?").run(data.id,orderId);
    res.json({orderId,paymentUrl:data.confirmation?.confirmation_url});
  }catch(e){
    db.prepare("UPDATE orders SET status='payment_error' WHERE id=?").run(orderId);
    res.status(502).json({error:"Не удалось создать платёж: "+e.message});
  }
});
app.post("/api/yookassa/webhook",async(req,res)=>{
  const event=req.body;
  const paymentId=event?.object?.id;
  if(!paymentId) return res.sendStatus(200);
  try{
    const credentials=Buffer.from(process.env.YOOKASSA_SHOP_ID+":"+process.env.YOOKASSA_SECRET_KEY).toString("base64");
    const check=await fetch("https://api.yookassa.ru/v3/payments/"+encodeURIComponent(paymentId),{headers:{Authorization:"Basic "+credentials}});
    if(!check.ok) return res.sendStatus(503);
    const payment=await check.json();
    const orderId=payment.metadata?.order_id;
    if(orderId){
      if(payment.status==="succeeded"){
        const tx=db.transaction(()=>{
          const order=db.prepare("SELECT * FROM orders WHERE id=?").get(orderId);
          if(!order || order.status==="paid") return;
          db.prepare("UPDATE orders SET status='paid' WHERE id=?").run(orderId);
          const rows=db.prepare("SELECT product_id,quantity FROM order_items WHERE order_id=?").all(orderId);
          rows.forEach(x=>db.prepare("UPDATE products SET stock=MAX(0,stock-?) WHERE id=?").run(x.quantity,x.product_id));
        });
        tx();
      }else if(payment.status==="canceled"){
        db.prepare("UPDATE orders SET status='canceled' WHERE id=? AND status='pending'").run(orderId);
      }
    }
  }catch(e){console.error("Webhook processing:",e.message);return res.sendStatus(500);}
  res.sendStatus(200);
});
app.get("/api/admin/products",auth,admin,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY created_at DESC").all()));
app.post("/api/admin/products",auth,admin,(req,res)=>{
  const {game,kind,title,description,price,image,stock}=req.body;
  if(!ALLOWED_GAMES.includes(game)||!ALLOWED_KINDS.includes(kind)||!String(title||"").trim()||!Number.isInteger(Number(price))||Number(price)<0||!Number.isInteger(Number(stock))||Number(stock)<0) return res.status(400).json({error:"Проверьте поля товара"});
  const id=uuid();
  db.prepare("INSERT INTO products(id,game,kind,title,description,price,image,stock) VALUES(?,?,?,?,?,?,?,?)").run(id,game,kind,title,description,Number(price),String(image||""),Number(stock));
  res.json({id});
});
app.patch("/api/admin/products/:id",auth,admin,(req,res)=>{
  const p=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id);
  if(!p)return res.sendStatus(404);
  const title=String(req.body.title??p.title).trim();
  const description=String(req.body.description??p.description);
  const price=Number(req.body.price??p.price);
  const stock=Number(req.body.stock??p.stock);
  const active=Number(req.body.active??p.active);
  const game=String(req.body.game??p.game);
  const kind=String(req.body.kind??p.kind);
  const image=String(req.body.image??p.image);
  if(!title||!Number.isInteger(price)||price<0||!Number.isInteger(stock)||stock<0||![0,1].includes(active)||!ALLOWED_GAMES.includes(game)||!ALLOWED_KINDS.includes(kind)){
    return res.status(400).json({error:"Некорректные значения"});
  }
  db.prepare("UPDATE products SET game=?,kind=?,title=?,description=?,price=?,image=?,stock=?,active=? WHERE id=?")
    .run(game,kind,title,description,price,image,stock,active,p.id);
  res.json({ok:true});
});
app.delete("/api/admin/products/:id",auth,admin,(req,res)=>{
  const p=db.prepare("SELECT id FROM products WHERE id=?").get(req.params.id);
  if(!p)return res.sendStatus(404);
  const used=db.prepare("SELECT COUNT(*) AS n FROM order_items WHERE product_id=?").get(p.id).n;
  if(used>0){
    db.prepare("UPDATE products SET active=0,stock=0 WHERE id=?").run(p.id);
    return res.json({ok:true,soft:true});
  }
  db.prepare("DELETE FROM products WHERE id=?").run(p.id);
  res.json({ok:true});
});
app.get("/api/admin/orders",auth,admin,(req,res)=>{
  const orders=db.prepare("SELECT o.*,u.nickname FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 300").all();
  const itemsStmt=db.prepare("SELECT title,quantity,unit_price FROM order_items WHERE order_id=?");
  res.json(orders.map(o=>({...o,items:itemsStmt.all(o.id)})));
});
app.patch("/api/admin/orders/:id",auth,admin,(req,res)=>{
  const o=db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id);
  if(!o)return res.sendStatus(404);
  const status=String(req.body.status||"");
  if(!ALLOWED_ORDER_STATUSES.includes(status))return res.status(400).json({error:"Недопустимый статус"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(status,o.id);
  res.json({ok:true});
});
app.get("/api/admin/users",auth,admin,(req,res)=>{
  res.json(db.prepare("SELECT id,nickname,role,created_at FROM users ORDER BY created_at DESC LIMIT 500").all());
});
app.patch("/api/admin/users/:id",auth,admin,(req,res)=>{
  const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.params.id);
  if(!u)return res.sendStatus(404);
  if(u.id===req.user.sub)return res.status(400).json({error:"Нельзя менять свою роль"});
  const role=String(req.body.role||"");
  if(!["user","admin"].includes(role))return res.status(400).json({error:"Недопустимая роль"});
  db.prepare("UPDATE users SET role=? WHERE id=?").run(role,u.id);
  res.json({ok:true});
});

app.get("/payment/return",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

const port=Number(process.env.PORT||3000);
app.listen(port,async()=>{
  const nick=process.env.ADMIN_NICK, pass=process.env.ADMIN_PASSWORD;
  if(nick&&pass){
    const exists=db.prepare("SELECT id FROM users WHERE nickname=?").get(nick);
    if(!exists){
      const hash=await bcrypt.hash(pass,12);
      db.prepare("INSERT INTO users(id,nickname,password_hash,role) VALUES(?,?,?,'admin')").run(uuid(),nick,hash);
      console.log("Admin account provisioned:",nick);
    }
  }
  console.log(`GAMEVAULT listening on ${port}`);
});
