# GAMEVAULT

Функциональный стартовый проект игрового маркетплейса: каталог PUBG / OXIDE / Minecraft, аккаунты пользователей, корзина, история заказов, админ-панель API и платёжный поток YooKassa с выбором СБП.

## Требования
- Node.js 20+
- npm
- HTTPS-домен для production
- Учётная запись продавца YooKassa и выданные ею `shop_id` / `secret_key`

## Запуск локально
```bash
cp .env.example .env
```
Заполните `.env`. Обязательно задайте `JWT_SECRET` длиной не менее 32 символов и уникальный `ADMIN_PASSWORD`.
```bash
npm install
npm start
```
Откройте `http://localhost:3000`.

При первом старте создаётся администратор из `ADMIN_NICK` и `ADMIN_PASSWORD`. Не публикуйте `.env` и не добавляйте его в Git.

## YooKassa / СБП
В кабинете YooKassa получите `YOOKASSA_SHOP_ID` и `YOOKASSA_SECRET_KEY`, укажите их в `.env`.
Для production установите:
- `BASE_URL=https://ваш-домен`
- `YOOKASSA_RETURN_URL=https://ваш-домен/payment/return`
- `COOKIE_SECURE=true`
- `NODE_ENV=production`

В настройках HTTP-уведомлений YooKassa укажите:
`https://ваш-домен/api/yookassa/webhook`

События платежей не считаются подтверждением сами по себе: обработчик повторно получает платёж через API YooKassa и меняет заказ на `paid` только при статусе `succeeded`. Для тестирования используйте тестовый магазин и тестовые ключи. Реальные платежи будут доступны только после активации магазина и выполнения требований провайдера.

## Админ-панель
Вход под администратором через обычную форму входа. После авторизации в шапке появляется кнопка **Админ**.

В панели три раздела:
- **Товары** — создание, полное редактирование (игра, тип, название, описание, цена, картинка, остаток, видимость), скрытие и удаление
- **Заказы** — просмотр состава и смена статуса: ожидает / оплачен / выдан / отменён
- **Пользователи** — список и смена роли (user ↔ admin)

API (защищены ролью admin):
- `GET/POST /api/admin/products`
- `PATCH/DELETE /api/admin/products/:id`
- `GET /api/admin/orders` · `PATCH /api/admin/orders/:id` `{ status }`
- `GET /api/admin/users` · `PATCH /api/admin/users/:id` `{ role }`

Пароль администратора не попадает во frontend.

## HTTPS в production (Nginx + Certbot)
Направьте DNS A/AAAA вашего домена на сервер, затем установите Nginx и Certbot. Пример Nginx-конфига:
```nginx
server {
    listen 80;
    server_name shop.example.com;
    location / { return 301 https://$host$request_uri; }
}
server {
    listen 443 ssl http2;
    server_name shop.example.com;
    ssl_certificate /etc/letsencrypt/live/shop.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/shop.example.com/privkey.pem;
    client_max_body_size 2m;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```
Выпустите сертификат через Certbot и включите автопродление. Запускайте Node под менеджером процессов (например, systemd), не от root.

## Важные границы текущей версии
- В каталоге лежат демонстрационные карточки и цены; замените их реальными товарами через админ API.
- Веб-админка для редактирования каталога и управления заказами — следующий слой; текущая версия уже имеет защищённые админские API.
- Перед продажей аккаунтов конкретных игр проверьте правила издателей и права на передачу аккаунтов. Некоторые платформы ограничивают или запрещают такую передачу.
- Для цифровых услуг оформите точное описание, сроки, условия выполнения и порядок возврата.
- Добавьте политику конфиденциальности, оферту, контакты продавца и налоговые/потребительские сведения до публичного запуска.
- Перед реальным приёмом денег проведите тестовые платежи, отмену и сверку webhook-статусов.
